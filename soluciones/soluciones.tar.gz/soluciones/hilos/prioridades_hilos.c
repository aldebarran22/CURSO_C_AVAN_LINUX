#define _GNU_SOURCE

#include <errno.h>
#include <pthread.h>
#include <sched.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define LOW_PRIORITY     10
#define MEDIUM_PRIORITY  20
#define HIGH_PRIORITY    30

#define LOW_WORK_MS      2000
#define MEDIUM_WORK_MS   5000

static pthread_mutex_t resource_mutex;

/*
 * Este mutex y esta condición solamente se utilizan
 * para garantizar que el hilo bajo adquiera primero
 * el mutex que queremos estudiar.
 */
static pthread_mutex_t start_mutex =
    PTHREAD_MUTEX_INITIALIZER;

static pthread_cond_t low_has_mutex =
    PTHREAD_COND_INITIALIZER;

static int low_is_ready = 0;

static double elapsed_seconds(
    const struct timespec *start,
    const struct timespec *end)
{
    time_t seconds =
        end->tv_sec - start->tv_sec;

    long nanoseconds =
        end->tv_nsec - start->tv_nsec;

    return (double)seconds +
           (double)nanoseconds / 1000000000.0;
}

static void busy_work(long milliseconds)
{
    struct timespec start;
    struct timespec now;

    if (clock_gettime(
            CLOCK_MONOTONIC,
            &start) != 0) {
        perror("clock_gettime");
        return;
    }

    volatile unsigned long counter = 0;

    do {
        /*
         * Trabajo deliberadamente intensivo en CPU.
         */
        counter++;

        if (clock_gettime(
                CLOCK_MONOTONIC,
                &now) != 0) {
            perror("clock_gettime");
            return;
        }
    } while (elapsed_seconds(
                 &start,
                 &now) * 1000.0 < milliseconds);

    /*
     * Evita que el compilador considere que counter
     * no se utiliza.
     */
    (void)counter;
}

static int configure_current_thread(
    const char *name,
    int priority)
{
    struct sched_param parameters = {
        .sched_priority = priority
    };

    int error = pthread_setschedparam(
        pthread_self(),
        SCHED_FIFO,
        &parameters
    );

    if (error != 0) {
        fprintf(
            stderr,
            "%s: pthread_setschedparam: %s\n",
            name,
            strerror(error)
        );

        return -1;
    }

    int policy;
    struct sched_param current;

    error = pthread_getschedparam(
        pthread_self(),
        &policy,
        &current
    );

    if (error != 0) {
        fprintf(
            stderr,
            "%s: pthread_getschedparam: %s\n",
            name,
            strerror(error)
        );

        return -1;
    }

    printf(
        "%s configurado: política=%s, prioridad=%d\n",
        name,
        policy == SCHED_FIFO
            ? "SCHED_FIFO"
            : "otra",
        current.sched_priority
    );

    return 0;
}

static void wait_until_low_has_mutex(void)
{
    pthread_mutex_lock(&start_mutex);

    while (!low_is_ready) {
        pthread_cond_wait(
            &low_has_mutex,
            &start_mutex
        );
    }

    pthread_mutex_unlock(&start_mutex);
}

static void *low_thread(void *argument)
{
    (void)argument;

    if (configure_current_thread(
            "BAJO",
            LOW_PRIORITY) != 0) {
        return NULL;
    }

    pthread_mutex_lock(&resource_mutex);

    puts(
        "BAJO: adquiere el mutex y comienza el trabajo"
    );

    pthread_mutex_lock(&start_mutex);

    low_is_ready = 1;

    pthread_cond_broadcast(&low_has_mutex);

    pthread_mutex_unlock(&start_mutex);

    /*
     * Mientras realiza este trabajo:
     *
     * - ALTO quedará bloqueado esperando resource_mutex.
     * - MEDIO intentará consumir CPU.
     */
    busy_work(LOW_WORK_MS);

    puts(
        "BAJO: termina el trabajo y libera el mutex"
    );

    pthread_mutex_unlock(&resource_mutex);

    return NULL;
}

static void *high_thread(void *argument)
{
    (void)argument;

    if (configure_current_thread(
            "ALTO",
            HIGH_PRIORITY) != 0) {
        return NULL;
    }

    wait_until_low_has_mutex();

    struct timespec start;
    struct timespec end;

    clock_gettime(CLOCK_MONOTONIC, &start);

    puts(
        "ALTO: intenta adquirir el mutex"
    );

    pthread_mutex_lock(&resource_mutex);

    clock_gettime(CLOCK_MONOTONIC, &end);

    printf(
        "ALTO: adquiere el mutex después de %.3f segundos\n",
        elapsed_seconds(&start, &end)
    );

    pthread_mutex_unlock(&resource_mutex);

    return NULL;
}

static void *medium_thread(void *argument)
{
    (void)argument;

    if (configure_current_thread(
            "MEDIO",
            MEDIUM_PRIORITY) != 0) {
        return NULL;
    }

    wait_until_low_has_mutex();

    /*
     * Da una pequeña oportunidad al hilo ALTO
     * para bloquearse esperando el mutex.
     */
    struct timespec delay = {
        .tv_sec = 0,
        .tv_nsec = 100000000
    };

    nanosleep(&delay, NULL);

    puts(
        "MEDIO: comienza trabajo intensivo sin necesitar el mutex"
    );

    busy_work(MEDIUM_WORK_MS);

    puts(
        "MEDIO: termina su trabajo"
    );

    return NULL;
}

static int initialize_resource_mutex(
    int use_priority_inheritance)
{
    pthread_mutexattr_t attributes;

    int error = pthread_mutexattr_init(
        &attributes
    );

    if (error != 0) {
        fprintf(
            stderr,
            "pthread_mutexattr_init: %s\n",
            strerror(error)
        );

        return -1;
    }

    int protocol = use_priority_inheritance
        ? PTHREAD_PRIO_INHERIT
        : PTHREAD_PRIO_NONE;

    error = pthread_mutexattr_setprotocol(
        &attributes,
        protocol
    );

    if (error != 0) {
        fprintf(
            stderr,
            "pthread_mutexattr_setprotocol: %s\n",
            strerror(error)
        );

        pthread_mutexattr_destroy(&attributes);
        return -1;
    }

    error = pthread_mutex_init(
        &resource_mutex,
        &attributes
    );

    pthread_mutexattr_destroy(&attributes);

    if (error != 0) {
        fprintf(
            stderr,
            "pthread_mutex_init: %s\n",
            strerror(error)
        );

        return -1;
    }

    return 0;
}

int main(int argc, char *argv[])
{
    int use_priority_inheritance = 1; // inherit:heredada

   
    pthread_t low;
    pthread_t high;
    pthread_t medium;

    int error = pthread_create(
        &low,
        NULL,
        low_thread,
        NULL
    );

    if (error != 0) {
        fprintf(
            stderr,
            "pthread_create BAJO: %s\n",
            strerror(error)
        );

        pthread_mutex_destroy(&resource_mutex);
        return EXIT_FAILURE;
    }

    error = pthread_create(
        &high,
        NULL,
        high_thread,
        NULL
    );

    if (error != 0) {
        fprintf(
            stderr,
            "pthread_create ALTO: %s\n",
            strerror(error)
        );

        return EXIT_FAILURE;
    }

    error = pthread_create(
        &medium,
        NULL,
        medium_thread,
        NULL
    );

    if (error != 0) {
        fprintf(
            stderr,
            "pthread_create MEDIO: %s\n",
            strerror(error)
        );

        return EXIT_FAILURE;
    }

    pthread_join(low, NULL);
    pthread_join(high, NULL);
    pthread_join(medium, NULL);

    pthread_mutex_destroy(&resource_mutex);
    pthread_cond_destroy(&low_has_mutex);
    pthread_mutex_destroy(&start_mutex);

    return EXIT_SUCCESS;
}
