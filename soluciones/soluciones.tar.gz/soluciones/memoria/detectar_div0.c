// Prueba a detectauna division por cero

#include <stdio.h>

void div0(int a, int b){
    printf("\nValor %d", a / b);
}

int main(){
    div0(8, 0);
    return 0;
}