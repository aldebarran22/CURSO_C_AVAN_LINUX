//Ejemplo de codigo incorrecto:

#include <stdlib.h>

int main(void){
    int *values = malloc(4 * sizeof(int));

    if (values == NULL){
        return EXIT_FAILURE;
    }

    values[4] = 100; // desbordamiento

    free(values);
    values[0] = 200; // Acceso despues de liberacion.

    free(values); // Doble liberacion
    return EXIT_SUCCESS;
}

/*
Pruebas con las herramientas:
si hacemos: gcc memoria.c -o memoria
y: valgrind ./memoria

Se detectan los errores pero es mejor hacer:
LO VAMOS A VER EN EL INFORME DE COMPILACION!
gcc \
    -std=c11 \
    -Wall \
    -Wextra \
    -Wpedantic \
    -g \
    -O0 \
    memoria.c \
    -o memoria

valgrind \
    --tool=memcheck \
    --leak-check=full \
    --show-leak-kinds=all \
    --track-origins=yes
    ./memoria

El parametro --tool=memcheck puede omitirse porque es la 
opcion por defecto que utiliza valgrind

============ Parametros ==============================
-g
    Añade información de depuración.
    Valgrind puede mostrar nombres de funciones
    y números de línea.

-O0
   Desactiva las optimizaciones.
    facilita que los errores corresponden
    directamente con las líneas *el código fuente.


============ Valgrind ================================
--tool=memcheck
    Selecciona Memcheck.
    Es la herramienta de Valgrind para detectar errores de memoria.
    Es la herramienta predeterminada, por lo que puede omitirse.

--leak-check=full
    Muestra información detallada sobre las fugas de memoria,
    incluyendo la pila de llamadas donde se reservó el bloque.

--show-leak-kinds=all
    Muestra todos los tipos de fugas:
    definitely lost, indirectly lost, possibly lost y still reachable.

--track-origins=yes
    Intenta localizar el origen de los valores no inicializados.
    Hace que la ejecución sea más lenta, pero proporciona más información. 【2-c241d0】【3-f032cc】

--num-callers=20
    Muestra hasta 20 llamadas en cada traza.
    Es útil cuando el error se origina dentro de varias funciones.

./errores_memoria
    Es el programa que Valgrind debe ejecutar y analizar.

=============== AddressSanitizer ===========================
gcc -std=c11 \
-Wall -Wextra -Wpedantic \
-g -O1 \
-fsanitize=address \
-fno-omit-frame-pointer \
memoria.c \
-o memoria_asan

Probar a ejecutar con ./memoria

*/