#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

typedef struct {
	uint8_t type;
	uint32_t identifier;
} message_t;

int main(){
	printf("Size: %zu\n", sizeof(message_t));
	printf("Offset type: %zu\n", offsetof(message_t, type));
	printf("Offset identifier: %zu\n",
	offsetof(message_t, identifier));
}
