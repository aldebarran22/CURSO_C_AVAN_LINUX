#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#pragma pack(push, 1)

typedef struct {
    uint8_t type;
    uint32_t length;
} header_t;

#pragma pack(pop)


typedef struct {
    uint8_t type;
    uint32_t length;
} header_t2;

int main(void)
{
    puts("pragma pack:");
    printf("Size: %zu\n", sizeof(header_t));
    printf("Offset type: %zu\n", offsetof(header_t, type));
    printf("Offset length: %zu\n", offsetof(header_t, length));

    puts("\npragma sin pack:");
    printf("Size: %zu\n", sizeof(header_t2));
    printf("Offset type: %zu\n", offsetof(header_t2, type));
    printf("Offset length: %zu\n", offsetof(header_t2, length));

    puts("");
    return 0;
}
