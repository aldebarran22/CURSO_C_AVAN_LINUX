
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>


static void alineamientos(void){
    char buffer[9] = "12345678";
    int32_t value;

    memcpy(&value, buffer + 1, sizeof(value));

    // PRId32 macro formato para printf
    // Es para imprimir un valor correcto de int32_t
    printf("Valor decimal: %" PRId32 "\n", value);
    printf("Valor hexadecimal: 0x%08" PRIx32 "\n",(uint32_t)value);

    // Los muestra Valor hexadecimal: 0x35343332
    // Es little endian


    printf("Cadena: %s\n", buffer + 1);
    printf("Primer caracter: %c\n", buffer[1]);

    //PRId32: decimal con signo.
    //PRIu32: decimal sin signo.
    //PRIx32: hexadecimal en minúsculas.
    //PRIX32: hexadecimal en mayúsculas.

    // Caracteres en HEX:
    puts("\nchars en HEX: ");
    for (int i = 0 ; i < 8 ; i++){
        printf("%c %X\n", buffer[i], buffer[i]);    
    }
    puts("");

    // Sin utilizar memcpy con otro puntero:
    // No es correcto el alineamiento y puede producir 
    // comportamiento indefinido: aunque el mismo resultado
    // no esta hecho de la forma correcta.
    int32_t *ptr = (int32_t *) (buffer + 1);
    printf("\nValor hexadecimal: 0x%08" PRIx32 "\n",(uint32_t)*ptr);

}


int main(void){
    alineamientos();
    puts("");
    return 0;
}